import { Request, Response, NextFunction } from "express";
import { verifyToken, JwtPayload } from "../utils/jwt";
import { prisma } from "../lib/prisma";

// Extiende Express.Request para llevar el usuario autenticado y su tenant
declare global {
  namespace Express {
    interface Request {
      auth?: JwtPayload;
    }
  }
}

export async function requireAuth(req: Request, res: Response, next: NextFunction) {
  try {
    const header = req.headers.authorization;
    if (!header || !header.startsWith("Bearer ")) {
      return res.status(401).json({ error: "No autorizado. Falta token." });
    }
    const token = header.slice("Bearer ".length);
    const payload = verifyToken(token);

    // Verifica que la empresa siga activa/con suscripción válida
    const company = await prisma.company.findUnique({ where: { id: payload.companyId } });
    if (!company) return res.status(401).json({ error: "Empresa no encontrada." });

    const blockedStatuses = ["CANCELED", "INCOMPLETE"];
    if (blockedStatuses.includes(company.subscriptionStatus)) {
      return res.status(402).json({
        error: "La suscripción de tu empresa no está activa. Actualiza tu método de pago para continuar.",
        subscriptionStatus: company.subscriptionStatus,
      });
    }

    req.auth = payload;
    next();
  } catch (err) {
    return res.status(401).json({ error: "Token inválido o expirado." });
  }
}

// Restringe una ruta a ciertos roles (jerarquía: OWNER > ADMIN > MANAGER > EMPLOYEE)
export function requireRole(...roles: JwtPayload["role"][]) {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.auth || !roles.includes(req.auth.role)) {
      return res.status(403).json({ error: "No tienes permisos para esta acción." });
    }
    next();
  };
}
