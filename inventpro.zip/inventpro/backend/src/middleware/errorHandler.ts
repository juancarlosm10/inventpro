import { Request, Response, NextFunction } from "express";
import { ZodError } from "zod";

// Middleware central de errores: normaliza la respuesta para toda la API
export function errorHandler(err: any, req: Request, res: Response, next: NextFunction) {
  if (err instanceof ZodError) {
    return res.status(400).json({ error: "Datos inválidos", details: err.flatten() });
  }
  if (err?.code === "P2002") {
    return res.status(409).json({ error: "Ya existe un registro con ese valor único.", meta: err.meta });
  }
  if (err?.code === "P2025") {
    return res.status(404).json({ error: "Registro no encontrado." });
  }
  console.error(err);
  return res.status(err.status || 500).json({ error: err.message || "Error interno del servidor" });
}

// Envuelve controladores async para propagar errores a errorHandler sin try/catch repetido
export function asyncHandler(fn: (req: Request, res: Response, next: NextFunction) => Promise<any>) {
  return (req: Request, res: Response, next: NextFunction) => fn(req, res, next).catch(next);
}
