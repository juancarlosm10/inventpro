import { Router } from "express";
import { z } from "zod";
import { prisma } from "../lib/prisma";
import { requireAuth, requireRole } from "../middleware/auth";
import { asyncHandler } from "../middleware/errorHandler";

const router = Router();
router.use(requireAuth);

const productSchema = z.object({
  sku: z.string().min(1),
  barcode: z.string().optional(),
  name: z.string().min(1),
  description: z.string().optional(),
  categoryId: z.string().optional().nullable(),
  unit: z.string().default("UND"),
  costPrice: z.number().nonnegative().default(0),
  salePrice: z.number().nonnegative().default(0),
  taxRate: z.number().min(0).max(100).default(0),
  minStock: z.number().int().min(0).default(0),
  maxStock: z.number().int().min(0).optional().nullable(),
});

// GET /api/products?search=&categoryId=&lowStock=true&page=&pageSize=
router.get(
  "/",
  asyncHandler(async (req, res) => {
    const { companyId } = req.auth!;
    const { search, categoryId, lowStock, page = "1", pageSize = "20" } = req.query as Record<string, string>;

    const where: any = { companyId, isActive: true };
    if (search) {
      where.OR = [
        { name: { contains: search, mode: "insensitive" } },
        { sku: { contains: search, mode: "insensitive" } },
        { barcode: { contains: search, mode: "insensitive" } },
      ];
    }
    if (categoryId) where.categoryId = categoryId;

    const take = Math.min(parseInt(pageSize) || 20, 100);
    const skip = (Math.max(parseInt(page) || 1, 1) - 1) * take;

    const [items, total] = await Promise.all([
      prisma.product.findMany({
        where,
        include: { category: true, stocks: { include: { warehouse: true } } },
        orderBy: { name: "asc" },
        take,
        skip,
      }),
      prisma.product.count({ where }),
    ]);

    const withTotals = items.map((p: any) => {
      const totalStock = p.stocks.reduce((acc: number, s: any) => acc + s.quantity, 0);
      return { ...p, totalStock, isLowStock: totalStock <= p.minStock };
    });

    const filtered = lowStock === "true" ? withTotals.filter((p: any) => p.isLowStock) : withTotals;

    res.json({ items: filtered, total, page: Number(page), pageSize: take });
  })
);

router.get(
  "/:id",
  asyncHandler(async (req, res) => {
    const product = await prisma.product.findFirst({
      where: { id: req.params.id, companyId: req.auth!.companyId },
      include: { category: true, stocks: { include: { warehouse: true } } },
    });
    if (!product) return res.status(404).json({ error: "Producto no encontrado." });
    res.json(product);
  })
);

// Solo roles con permiso operativo pueden crear/editar/eliminar catálogo
router.post(
  "/",
  requireRole("OWNER", "ADMIN", "MANAGER"),
  asyncHandler(async (req, res) => {
    const data = productSchema.parse(req.body);
    const { companyId } = req.auth!;

    const product = await prisma.product.create({
      data: { ...data, companyId },
    });

    // Inicializa stock en 0 para cada bodega existente de la empresa
    const warehouses = await prisma.warehouse.findMany({ where: { companyId, isActive: true } });
    if (warehouses.length) {
      await prisma.productStock.createMany({
        data: warehouses.map((w: any) => ({ productId: product.id, warehouseId: w.id, quantity: 0 })),
      });
    }

    await prisma.auditLog.create({
      data: { companyId, userId: req.auth!.userId, action: "CREATE", entity: "Product", entityId: product.id },
    });

    res.status(201).json(product);
  })
);

router.put(
  "/:id",
  requireRole("OWNER", "ADMIN", "MANAGER"),
  asyncHandler(async (req, res) => {
    const data = productSchema.partial().parse(req.body);
    const { companyId, userId } = req.auth!;

    const existing = await prisma.product.findFirst({ where: { id: req.params.id, companyId } });
    if (!existing) return res.status(404).json({ error: "Producto no encontrado." });

    const product = await prisma.product.update({ where: { id: req.params.id }, data });
    await prisma.auditLog.create({ data: { companyId, userId, action: "UPDATE", entity: "Product", entityId: product.id } });
    res.json(product);
  })
);

// Baja lógica (no se borra el histórico de movimientos/órdenes)
router.delete(
  "/:id",
  requireRole("OWNER", "ADMIN"),
  asyncHandler(async (req, res) => {
    const { companyId, userId } = req.auth!;
    const existing = await prisma.product.findFirst({ where: { id: req.params.id, companyId } });
    if (!existing) return res.status(404).json({ error: "Producto no encontrado." });

    await prisma.product.update({ where: { id: req.params.id }, data: { isActive: false } });
    await prisma.auditLog.create({ data: { companyId, userId, action: "DELETE", entity: "Product", entityId: req.params.id } });
    res.status(204).send();
  })
);

export default router;
