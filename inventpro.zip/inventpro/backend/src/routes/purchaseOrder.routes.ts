import { Router } from "express";
import { z } from "zod";
import { prisma } from "../lib/prisma";
import { requireAuth, requireRole } from "../middleware/auth";
import { asyncHandler } from "../middleware/errorHandler";
import { adjustStock } from "./stock.routes";

const router = Router();
router.use(requireAuth);

const itemSchema = z.object({ productId: z.string(), quantity: z.number().int().positive(), unitCost: z.number().nonnegative() });
const createSchema = z.object({
  supplierId: z.string(),
  warehouseId: z.string(),
  expectedDate: z.string().optional(),
  notes: z.string().optional(),
  items: z.array(itemSchema).min(1),
});

async function nextCode(companyId: string, prefix: string, model: "purchaseOrder" | "salesOrder") {
  const count = await (prisma[model] as any).count({ where: { companyId } });
  return `${prefix}-${String(count + 1).padStart(4, "0")}`;
}

// GET /api/purchase-orders
router.get("/", asyncHandler(async (req, res) => {
  const { status } = req.query as Record<string, string>;
  const where: any = { companyId: req.auth!.companyId };
  if (status) where.status = status;
  const orders = await prisma.purchaseOrder.findMany({
    where, include: { supplier: true, warehouse: true, items: { include: { product: true } } }, orderBy: { createdAt: "desc" },
  });
  res.json(orders);
}));

// POST /api/purchase-orders -> crea orden en estado DRAFT/ORDERED (aún no afecta stock)
router.post("/", requireRole("OWNER", "ADMIN", "MANAGER"), asyncHandler(async (req, res) => {
  const data = createSchema.parse(req.body);
  const { companyId } = req.auth!;
  const total = data.items.reduce((acc, i) => acc + i.quantity * i.unitCost, 0);
  const code = await nextCode(companyId, "OC", "purchaseOrder");

  const order = await prisma.purchaseOrder.create({
    data: {
      companyId,
      code,
      supplierId: data.supplierId,
      warehouseId: data.warehouseId,
      status: "ORDERED",
      expectedDate: data.expectedDate ? new Date(data.expectedDate) : undefined,
      notes: data.notes,
      total,
      items: { create: data.items.map((i: any) => ({ productId: i.productId, quantity: i.quantity, unitCost: i.unitCost })) },
    },
    include: { items: true },
  });

  res.status(201).json(order);
}));

const receiveSchema = z.object({
  items: z.array(z.object({ itemId: z.string(), receivedQty: z.number().int().positive() })).min(1),
});

// POST /api/purchase-orders/:id/receive -> recepción parcial o total; genera movimientos IN_PURCHASE y suma stock
router.post("/:id/receive", requireRole("OWNER", "ADMIN", "MANAGER"), asyncHandler(async (req, res) => {
  const data = receiveSchema.parse(req.body);
  const { companyId, userId } = req.auth!;

  const order = await prisma.purchaseOrder.findFirst({ where: { id: req.params.id, companyId }, include: { items: true } });
  if (!order) return res.status(404).json({ error: "Orden de compra no encontrada." });
  if (order.status === "RECEIVED" || order.status === "CANCELED") {
    return res.status(400).json({ error: `La orden ya está en estado ${order.status}.` });
  }

  await prisma.$transaction(async (tx: any) => {
    for (const recv of data.items) {
      const item = order.items.find((i: any) => i.id === recv.itemId);
      if (!item) throw Object.assign(new Error("Ítem de orden no encontrado."), { status: 400 });
      const remaining = item.quantity - item.receivedQty;
      if (recv.receivedQty > remaining) {
        throw Object.assign(new Error(`No puedes recibir más de lo pendiente para ${item.id} (pendiente: ${remaining}).`), { status: 400 });
      }

      await adjustStock(tx, item.productId, order.warehouseId, recv.receivedQty);
      await tx.purchaseOrderItem.update({ where: { id: item.id }, data: { receivedQty: { increment: recv.receivedQty } } });
      await tx.stockMovement.create({
        data: {
          companyId, productId: item.productId, warehouseId: order.warehouseId, type: "IN_PURCHASE",
          quantity: recv.receivedQty, unitCost: item.unitCost, referenceType: "PURCHASE_ORDER", referenceId: order.id, userId,
        },
      });
    }

    const refreshedItems = await tx.purchaseOrderItem.findMany({ where: { purchaseOrderId: order.id } });
    const fullyReceived = refreshedItems.every((i: any) => i.receivedQty >= i.quantity);
    const anyReceived = refreshedItems.some((i: any) => i.receivedQty > 0);
    await tx.purchaseOrder.update({
      where: { id: order.id },
      data: { status: fullyReceived ? "RECEIVED" : anyReceived ? "PARTIALLY_RECEIVED" : order.status },
    });
  });

  const updated = await prisma.purchaseOrder.findUnique({ where: { id: order.id }, include: { items: true } });
  res.json(updated);
}));

router.post("/:id/cancel", requireRole("OWNER", "ADMIN"), asyncHandler(async (req, res) => {
  const order = await prisma.purchaseOrder.findFirst({ where: { id: req.params.id, companyId: req.auth!.companyId } });
  if (!order) return res.status(404).json({ error: "No encontrada." });
  if (order.status === "PARTIALLY_RECEIVED" || order.status === "RECEIVED") {
    return res.status(400).json({ error: "No se puede cancelar una orden ya recibida parcial o totalmente." });
  }
  await prisma.purchaseOrder.update({ where: { id: order.id }, data: { status: "CANCELED" } });
  res.json({ ok: true });
}));

export default router;
