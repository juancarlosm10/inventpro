import { Router } from "express";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { prisma } from "../lib/prisma";
import { signToken } from "../utils/jwt";
import { asyncHandler } from "../middleware/errorHandler";
import { requireAuth } from "../middleware/auth";

const router = Router();

const registerSchema = z.object({
  companyName: z.string().min(2),
  ownerName: z.string().min(2),
  email: z.string().email(),
  password: z.string().min(8, "La contraseña debe tener al menos 8 caracteres"),
});

// POST /api/auth/register  -> crea la empresa (tenant), su bodega principal y el usuario OWNER.
// Inicia un periodo de prueba de 14 días antes de exigir suscripción activa.
router.post(
  "/register",
  asyncHandler(async (req, res) => {
    const data = registerSchema.parse(req.body);

    const slugBase = data.companyName.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
    const slug = `${slugBase}-${Math.random().toString(36).slice(2, 7)}`;
    const passwordHash = await bcrypt.hash(data.password, 10);
    const trialEndsAt = new Date();
    trialEndsAt.setDate(trialEndsAt.getDate() + 14);

    const result = await prisma.$transaction(async (tx: any) => {
      const company = await tx.company.create({
        data: {
          name: data.companyName,
          slug,
          subscriptionStatus: "TRIALING",
          trialEndsAt,
        },
      });

      const user = await tx.user.create({
        data: {
          companyId: company.id,
          name: data.ownerName,
          email: data.email.toLowerCase(),
          passwordHash,
          role: "OWNER",
        },
      });

      await tx.warehouse.create({
        data: {
          companyId: company.id,
          name: "Bodega Principal",
          isDefault: true,
        },
      });

      return { company, user };
    });

    const token = signToken({ userId: result.user.id, companyId: result.company.id, role: "OWNER" });
    res.status(201).json({
      token,
      user: { id: result.user.id, name: result.user.name, email: result.user.email, role: result.user.role },
      company: { id: result.company.id, name: result.company.name, slug: result.company.slug, subscriptionStatus: result.company.subscriptionStatus, trialEndsAt: result.company.trialEndsAt },
    });
  })
);

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string(),
});

// POST /api/auth/login
router.post(
  "/login",
  asyncHandler(async (req, res) => {
    const data = loginSchema.parse(req.body);
    const user = await prisma.user.findFirst({ where: { email: data.email.toLowerCase(), isActive: true } });
    if (!user) return res.status(401).json({ error: "Credenciales inválidas." });

    const valid = await bcrypt.compare(data.password, user.passwordHash);
    if (!valid) return res.status(401).json({ error: "Credenciales inválidas." });

    const company = await prisma.company.findUnique({ where: { id: user.companyId } });

    await prisma.user.update({ where: { id: user.id }, data: { lastLoginAt: new Date() } });

    const token = signToken({ userId: user.id, companyId: user.companyId, role: user.role });
    res.json({
      token,
      user: { id: user.id, name: user.name, email: user.email, role: user.role },
      company,
    });
  })
);

// GET /api/auth/me -> perfil del usuario autenticado + estado de la empresa
router.get(
  "/me",
  requireAuth,
  asyncHandler(async (req, res) => {
    const user = await prisma.user.findUnique({ where: { id: req.auth!.userId } });
    const company = await prisma.company.findUnique({ where: { id: req.auth!.companyId } });
    res.json({ user, company });
  })
);

export default router;
