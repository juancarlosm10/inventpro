import { Router } from "express";
import { prisma } from "../lib/prisma";
import { requireAuth, requireRole } from "../middleware/auth";
import { asyncHandler } from "../middleware/errorHandler";
import { stripe, STRIPE_PRICE_ID } from "../lib/stripe";

const router = Router();

// POST /api/billing/checkout -> crea una sesión de Stripe Checkout para suscripción $30/mes
router.post("/checkout", requireAuth, requireRole("OWNER"), asyncHandler(async (req, res) => {
  const company = await prisma.company.findUnique({ where: { id: req.auth!.companyId } });
  if (!company) return res.status(404).json({ error: "Empresa no encontrada." });
  if (!STRIPE_PRICE_ID) return res.status(500).json({ error: "STRIPE_PRICE_ID no configurado en el servidor." });

  let customerId = company.stripeCustomerId;
  if (!customerId) {
    const customer = await stripe.customers.create({ name: company.name, metadata: { companyId: company.id } });
    customerId = customer.id;
    await prisma.company.update({ where: { id: company.id }, data: { stripeCustomerId: customerId } });
  }

  const session = await stripe.checkout.sessions.create({
    mode: "subscription",
    customer: customerId,
    line_items: [{ price: STRIPE_PRICE_ID, quantity: 1 }],
    success_url: `${process.env.FRONTEND_URL}/billing?success=true`,
    cancel_url: `${process.env.FRONTEND_URL}/billing?canceled=true`,
    metadata: { companyId: company.id },
  });

  res.json({ url: session.url });
}));

// POST /api/billing/portal -> portal de autogestión de suscripción (cancelar, cambiar tarjeta, etc.)
router.post("/portal", requireAuth, requireRole("OWNER"), asyncHandler(async (req, res) => {
  const company = await prisma.company.findUnique({ where: { id: req.auth!.companyId } });
  if (!company?.stripeCustomerId) return res.status(400).json({ error: "Esta empresa aún no tiene un cliente de Stripe." });

  const session = await stripe.billingPortal.sessions.create({
    customer: company.stripeCustomerId,
    return_url: `${process.env.FRONTEND_URL}/billing`,
  });
  res.json({ url: session.url });
}));

// POST /api/billing/webhook -> recibe eventos de Stripe (requiere raw body, ver index.ts)
export const stripeWebhookHandler = asyncHandler(async (req: any, res) => {
  const sig = req.headers["stripe-signature"] as string;
  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET || "");
  } catch (err: any) {
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  const obj: any = event.data.object;

  switch (event.type) {
    case "checkout.session.completed": {
      const companyId = obj.metadata?.companyId;
      if (companyId) {
        await prisma.company.update({
          where: { id: companyId },
          data: { stripeSubscriptionId: obj.subscription, subscriptionStatus: "ACTIVE" },
        });
      }
      break;
    }
    case "invoice.paid": {
      const company = await prisma.company.findFirst({ where: { stripeCustomerId: obj.customer } });
      if (company) {
        await prisma.company.update({
          where: { id: company.id },
          data: { subscriptionStatus: "ACTIVE", currentPeriodEnd: new Date(obj.lines?.data?.[0]?.period?.end * 1000 || Date.now()) },
        });
      }
      break;
    }
    case "invoice.payment_failed": {
      const company = await prisma.company.findFirst({ where: { stripeCustomerId: obj.customer } });
      if (company) await prisma.company.update({ where: { id: company.id }, data: { subscriptionStatus: "PAST_DUE" } });
      break;
    }
    case "customer.subscription.deleted": {
      const company = await prisma.company.findFirst({ where: { stripeCustomerId: obj.customer } });
      if (company) await prisma.company.update({ where: { id: company.id }, data: { subscriptionStatus: "CANCELED" } });
      break;
    }
  }

  res.json({ received: true });
});

export default router;
