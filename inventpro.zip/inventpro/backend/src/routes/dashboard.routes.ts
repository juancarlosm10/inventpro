import { Router } from "express";
import { prisma } from "../lib/prisma";
import { requireAuth } from "../middleware/auth";
import { asyncHandler } from "../middleware/errorHandler";

const router = Router();
router.use(requireAuth);

// GET /api/dashboard/summary -> KPIs principales para la vista de inicio
router.get("/summary", asyncHandler(async (req, res) => {
  const { companyId } = req.auth!;

  const [products, stocks, openPurchaseOrders, openSalesOrders, recentMovements] = await Promise.all([
    prisma.product.findMany({ where: { companyId, isActive: true }, select: { id: true, name: true, sku: true, minStock: true, costPrice: true } }),
    prisma.productStock.findMany({ where: { product: { companyId } }, select: { productId: true, quantity: true } }),
    prisma.purchaseOrder.count({ where: { companyId, status: { in: ["ORDERED", "PARTIALLY_RECEIVED"] } } }),
    prisma.salesOrder.count({ where: { companyId, status: { in: ["CONFIRMED", "PARTIALLY_SHIPPED"] } } }),
    prisma.stockMovement.findMany({
      where: { companyId }, orderBy: { createdAt: "desc" }, take: 10,
      include: { product: { select: { name: true } }, warehouse: { select: { name: true } }, user: { select: { name: true } } },
    }),
  ]);

  const stockByProduct = new Map<string, number>();
  for (const s of stocks) stockByProduct.set(s.productId, (stockByProduct.get(s.productId) || 0) + s.quantity);

  let totalInventoryValue = 0;
  let lowStockCount = 0;
  const lowStockItems: any[] = [];

  for (const p of products) {
    const qty = stockByProduct.get(p.id) || 0;
    totalInventoryValue += qty * Number(p.costPrice);
    if (qty <= p.minStock) {
      lowStockCount++;
      lowStockItems.push({ id: p.id, name: p.name, sku: p.sku, currentStock: qty, minStock: p.minStock });
    }
  }

  res.json({
    totalProducts: products.length,
    totalInventoryValue,
    lowStockCount,
    lowStockItems: lowStockItems.slice(0, 10),
    openPurchaseOrders,
    openSalesOrders,
    recentMovements,
  });
}));

export default router;
