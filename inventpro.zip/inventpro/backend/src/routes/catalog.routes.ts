import { Router } from "express";
import { z } from "zod";
import { prisma } from "../lib/prisma";
import { requireAuth, requireRole } from "../middleware/auth";
import { asyncHandler } from "../middleware/errorHandler";

// Agrupa recursos de catálogo auxiliar: bodegas, categorías, proveedores, clientes
const router = Router();
router.use(requireAuth);

// ---------------- BODEGAS ----------------
const warehouseSchema = z.object({ name: z.string().min(1), address: z.string().optional() });

router.get("/warehouses", asyncHandler(async (req, res) => {
  const warehouses = await prisma.warehouse.findMany({ where: { companyId: req.auth!.companyId, isActive: true } });
  res.json(warehouses);
}));

router.post("/warehouses", requireRole("OWNER", "ADMIN"), asyncHandler(async (req, res) => {
  const data = warehouseSchema.parse(req.body);
  const warehouse = await prisma.warehouse.create({ data: { ...data, companyId: req.auth!.companyId } });
  res.status(201).json(warehouse);
}));

// ---------------- CATEGORÍAS ----------------
const categorySchema = z.object({ name: z.string().min(1), parentId: z.string().optional().nullable() });

router.get("/categories", asyncHandler(async (req, res) => {
  const categories = await prisma.category.findMany({ where: { companyId: req.auth!.companyId } });
  res.json(categories);
}));

router.post("/categories", requireRole("OWNER", "ADMIN", "MANAGER"), asyncHandler(async (req, res) => {
  const data = categorySchema.parse(req.body);
  const category = await prisma.category.create({ data: { ...data, companyId: req.auth!.companyId } });
  res.status(201).json(category);
}));

// ---------------- PROVEEDORES ----------------
const partySchema = z.object({
  name: z.string().min(1),
  taxId: z.string().optional(),
  email: z.string().email().optional().or(z.literal("")),
  phone: z.string().optional(),
  address: z.string().optional(),
});

router.get("/suppliers", asyncHandler(async (req, res) => {
  const suppliers = await prisma.supplier.findMany({ where: { companyId: req.auth!.companyId, isActive: true }, orderBy: { name: "asc" } });
  res.json(suppliers);
}));

router.post("/suppliers", requireRole("OWNER", "ADMIN", "MANAGER"), asyncHandler(async (req, res) => {
  const data = partySchema.parse(req.body);
  const supplier = await prisma.supplier.create({ data: { ...data, companyId: req.auth!.companyId } });
  res.status(201).json(supplier);
}));

router.put("/suppliers/:id", requireRole("OWNER", "ADMIN", "MANAGER"), asyncHandler(async (req, res) => {
  const data = partySchema.partial().parse(req.body);
  const supplier = await prisma.supplier.updateMany({ where: { id: req.params.id, companyId: req.auth!.companyId }, data });
  if (!supplier.count) return res.status(404).json({ error: "Proveedor no encontrado." });
  res.json({ ok: true });
}));

// ---------------- CLIENTES ----------------
router.get("/customers", asyncHandler(async (req, res) => {
  const customers = await prisma.customer.findMany({ where: { companyId: req.auth!.companyId, isActive: true }, orderBy: { name: "asc" } });
  res.json(customers);
}));

router.post("/customers", requireRole("OWNER", "ADMIN", "MANAGER"), asyncHandler(async (req, res) => {
  const data = partySchema.parse(req.body);
  const customer = await prisma.customer.create({ data: { ...data, companyId: req.auth!.companyId } });
  res.status(201).json(customer);
}));

router.put("/customers/:id", requireRole("OWNER", "ADMIN", "MANAGER"), asyncHandler(async (req, res) => {
  const data = partySchema.partial().parse(req.body);
  const customer = await prisma.customer.updateMany({ where: { id: req.params.id, companyId: req.auth!.companyId }, data });
  if (!customer.count) return res.status(404).json({ error: "Cliente no encontrado." });
  res.json({ ok: true });
}));

export default router;
