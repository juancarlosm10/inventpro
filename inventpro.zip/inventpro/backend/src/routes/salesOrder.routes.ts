import { Router } from "express";
import { z } from "zod";
import { prisma } from "../lib/prisma";
import { requireAuth, requireRole } from "../middleware/auth";
import { asyncHandler } from "../middleware/errorHandler";
import { adjustStock } from "./stock.routes";

const router = Router();
router.use(requireAuth);

const itemSchema = z.object({ productId: z.string(), quantity: z.number().int().positive(), unitPrice: z.number().nonnegative() });
const createSchema = z.object({
  customerId: z.string(),
  warehouseId: z.string(),
  notes: z.string().optional(),
  items: z.array(itemSchema).min(1),
});

async function nextCode(companyId: string) {
  const count = await prisma.salesOrder.count({ where: { companyId } });
  return `VT-${String(count + 1).padStart(4, "0")}`;
}

router.get("/", asyncHandler(async (req, res) => {
  const { status } = req.query as Record<string, string>;
  const where: any = { companyId: req.auth!.companyId };
  if (status) where.status = status;
  const orders = await prisma.salesOrder.findMany({
    where, include: { customer: true, warehouse: true, items: { include: { product: true } } }, orderBy: { createdAt: "desc" },
  });
  res.json(orders);
}));

// POST /api/sales-orders -> valida disponibilidad de stock antes de confirmar
router.post("/", requireRole("OWNER", "ADMIN", "MANAGER"), asyncHandler(async (req, res) => {
  const data = createSchema.parse(req.body);
  const { companyId } = req.auth!;

  // Verificación de disponibilidad (no reserva aún, solo valida al crear en DRAFT)
  for (const item of data.items) {
    const stock = await prisma.productStock.findUnique({
      where: { productId_warehouseId: { productId: item.productId, warehouseId: data.warehouseId } },
    });
    const available = (stock?.quantity || 0) - (stock?.reserved || 0);
    if (available < item.quantity) {
      const product = await prisma.product.findUnique({ where: { id: item.productId } });
      throw Object.assign(new Error(`Stock insuficiente para "${product?.name}". Disponible: ${available}, solicitado: ${item.quantity}.`), { status: 400 });
    }
  }

  const total = data.items.reduce((acc, i) => acc + i.quantity * i.unitPrice, 0);
  const code = await nextCode(companyId);

  const order = await prisma.$transaction(async (tx: any) => {
    const created = await tx.salesOrder.create({
      data: {
        companyId, code, customerId: data.customerId, warehouseId: data.warehouseId, status: "CONFIRMED",
        notes: data.notes, total,
        items: { create: data.items.map((i: any) => ({ productId: i.productId, quantity: i.quantity, unitPrice: i.unitPrice })) },
      },
      include: { items: true },
    });
    // Reserva el stock (no lo descuenta aún; el descuento real ocurre al despachar)
    for (const item of data.items) {
      await tx.productStock.update({
        where: { productId_warehouseId: { productId: item.productId, warehouseId: data.warehouseId } },
        data: { reserved: { increment: item.quantity } },
      });
    }
    return created;
  });

  res.status(201).json(order);
}));

const shipSchema = z.object({
  items: z.array(z.object({ itemId: z.string(), shippedQty: z.number().int().positive() })).min(1),
});

// POST /api/sales-orders/:id/ship -> despacho parcial/total: descuenta stock real y libera reserva
router.post("/:id/ship", requireRole("OWNER", "ADMIN", "MANAGER", "EMPLOYEE"), asyncHandler(async (req, res) => {
  const data = shipSchema.parse(req.body);
  const { companyId, userId } = req.auth!;

  const order = await prisma.salesOrder.findFirst({ where: { id: req.params.id, companyId }, include: { items: true } });
  if (!order) return res.status(404).json({ error: "Orden de venta no encontrada." });
  if (order.status === "SHIPPED" || order.status === "CANCELED") {
    return res.status(400).json({ error: `La orden ya está en estado ${order.status}.` });
  }

  await prisma.$transaction(async (tx: any) => {
    for (const ship of data.items) {
      const item = order.items.find((i: any) => i.id === ship.itemId);
      if (!item) throw Object.assign(new Error("Ítem no encontrado."), { status: 400 });
      const remaining = item.quantity - item.shippedQty;
      if (ship.shippedQty > remaining) {
        throw Object.assign(new Error(`No puedes despachar más de lo pendiente (pendiente: ${remaining}).`), { status: 400 });
      }

      await adjustStock(tx, item.productId, order.warehouseId, -ship.shippedQty);
      await tx.productStock.update({
        where: { productId_warehouseId: { productId: item.productId, warehouseId: order.warehouseId } },
        data: { reserved: { decrement: ship.shippedQty } },
      });
      await tx.salesOrderItem.update({ where: { id: item.id }, data: { shippedQty: { increment: ship.shippedQty } } });
      await tx.stockMovement.create({
        data: { companyId, productId: item.productId, warehouseId: order.warehouseId, type: "OUT_SALE", quantity: ship.shippedQty, referenceType: "SALES_ORDER", referenceId: order.id, userId },
      });
    }

    const refreshed = await tx.salesOrderItem.findMany({ where: { salesOrderId: order.id } });
    const fullyShipped = refreshed.every((i: any) => i.shippedQty >= i.quantity);
    const anyShipped = refreshed.some((i: any) => i.shippedQty > 0);
    await tx.salesOrder.update({
      where: { id: order.id },
      data: { status: fullyShipped ? "SHIPPED" : anyShipped ? "PARTIALLY_SHIPPED" : order.status },
    });
  });

  const updated = await prisma.salesOrder.findUnique({ where: { id: order.id }, include: { items: true } });
  res.json(updated);
}));

router.post("/:id/cancel", requireRole("OWNER", "ADMIN", "MANAGER"), asyncHandler(async (req, res) => {
  const { companyId } = req.auth!;
  const order = await prisma.salesOrder.findFirst({ where: { id: req.params.id, companyId }, include: { items: true } });
  if (!order) return res.status(404).json({ error: "No encontrada." });
  if (order.status === "SHIPPED") return res.status(400).json({ error: "No se puede cancelar una orden ya despachada." });

  await prisma.$transaction(async (tx: any) => {
    for (const item of order.items) {
      const pendingReserved = item.quantity - item.shippedQty;
      if (pendingReserved > 0) {
        await tx.productStock.update({
          where: { productId_warehouseId: { productId: item.productId, warehouseId: order.warehouseId } },
          data: { reserved: { decrement: pendingReserved } },
        });
      }
    }
    await tx.salesOrder.update({ where: { id: order.id }, data: { status: "CANCELED" } });
  });

  res.json({ ok: true });
}));

export default router;
