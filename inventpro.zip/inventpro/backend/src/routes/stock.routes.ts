import { Router } from "express";
import { z } from "zod";
import { prisma } from "../lib/prisma";
import { requireAuth, requireRole } from "../middleware/auth";
import { asyncHandler } from "../middleware/errorHandler";

const router = Router();
router.use(requireAuth);

// Ajusta (crea si no existe) el registro de stock de un producto en una bodega
async function adjustStock(tx: any, productId: string, warehouseId: string, delta: number) {
  const existing = await tx.productStock.findUnique({ where: { productId_warehouseId: { productId, warehouseId } } });
  if (existing) {
    const newQty = existing.quantity + delta;
    if (newQty < 0) throw Object.assign(new Error("Stock insuficiente para esta operación."), { status: 400 });
    return tx.productStock.update({ where: { id: existing.id }, data: { quantity: newQty } });
  }
  if (delta < 0) throw Object.assign(new Error("Stock insuficiente para esta operación."), { status: 400 });
  return tx.productStock.create({ data: { productId, warehouseId, quantity: delta } });
}

const manualMovementSchema = z.object({
  productId: z.string(),
  warehouseId: z.string(),
  type: z.enum(["IN_ADJUSTMENT", "OUT_ADJUSTMENT", "IN_RETURN", "OUT_RETURN"]),
  quantity: z.number().int().positive(),
  reason: z.string().optional(),
});

// POST /api/stock/movements  -> entradas/salidas manuales (ajustes, devoluciones)
router.post(
  "/movements",
  requireRole("OWNER", "ADMIN", "MANAGER", "EMPLOYEE"),
  asyncHandler(async (req, res) => {
    const data = manualMovementSchema.parse(req.body);
    const { companyId, userId } = req.auth!;
    const isInbound = data.type.startsWith("IN_");
    const delta = isInbound ? data.quantity : -data.quantity;

    const movement = await prisma.$transaction(async (tx: any) => {
      await adjustStock(tx, data.productId, data.warehouseId, delta);
      return tx.stockMovement.create({
        data: {
          companyId,
          productId: data.productId,
          warehouseId: data.warehouseId,
          type: data.type,
          quantity: data.quantity,
          reason: data.reason,
          referenceType: "MANUAL",
          userId,
        },
      });
    });

    res.status(201).json(movement);
  })
);

const transferSchema = z.object({
  productId: z.string(),
  fromWarehouseId: z.string(),
  toWarehouseId: z.string(),
  quantity: z.number().int().positive(),
  reason: z.string().optional(),
});

// POST /api/stock/transfer -> traslado entre bodegas (dos movimientos ligados)
router.post(
  "/transfer",
  requireRole("OWNER", "ADMIN", "MANAGER"),
  asyncHandler(async (req, res) => {
    const data = transferSchema.parse(req.body);
    if (data.fromWarehouseId === data.toWarehouseId) {
      return res.status(400).json({ error: "La bodega origen y destino deben ser diferentes." });
    }
    const { companyId, userId } = req.auth!;

    const result = await prisma.$transaction(async (tx: any) => {
      await adjustStock(tx, data.productId, data.fromWarehouseId, -data.quantity);
      await adjustStock(tx, data.productId, data.toWarehouseId, data.quantity);

      const out = await tx.stockMovement.create({
        data: { companyId, productId: data.productId, warehouseId: data.fromWarehouseId, type: "TRANSFER_OUT", quantity: data.quantity, reason: data.reason, referenceType: "TRANSFER", userId },
      });
      const inMove = await tx.stockMovement.create({
        data: { companyId, productId: data.productId, warehouseId: data.toWarehouseId, type: "TRANSFER_IN", quantity: data.quantity, reason: data.reason, referenceType: "TRANSFER", referenceId: out.id, userId },
      });
      return { out, in: inMove };
    });

    res.status(201).json(result);
  })
);

// GET /api/stock/movements?productId=&warehouseId=&from=&to=  -> kardex / trazabilidad
router.get(
  "/movements",
  asyncHandler(async (req, res) => {
    const { productId, warehouseId, from, to, page = "1", pageSize = "50" } = req.query as Record<string, string>;
    const where: any = { companyId: req.auth!.companyId };
    if (productId) where.productId = productId;
    if (warehouseId) where.warehouseId = warehouseId;
    if (from || to) where.createdAt = { ...(from ? { gte: new Date(from) } : {}), ...(to ? { lte: new Date(to) } : {}) };

    const take = Math.min(parseInt(pageSize) || 50, 200);
    const skip = (Math.max(parseInt(page) || 1, 1) - 1) * take;

    const [items, total] = await Promise.all([
      prisma.stockMovement.findMany({
        where,
        include: { product: { select: { name: true, sku: true } }, warehouse: { select: { name: true } }, user: { select: { name: true } } },
        orderBy: { createdAt: "desc" },
        take,
        skip,
      }),
      prisma.stockMovement.count({ where }),
    ]);

    res.json({ items, total, page: Number(page), pageSize: take });
  })
);

export { adjustStock };
export default router;
