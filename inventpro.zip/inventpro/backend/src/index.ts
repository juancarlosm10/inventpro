import "dotenv/config";
import express from "express";
import cors from "cors";
import helmet from "helmet";
import morgan from "morgan";
import rateLimit from "express-rate-limit";

import authRoutes from "./routes/auth.routes";
import productRoutes from "./routes/product.routes";
import catalogRoutes from "./routes/catalog.routes";
import stockRoutes from "./routes/stock.routes";
import purchaseOrderRoutes from "./routes/purchaseOrder.routes";
import salesOrderRoutes from "./routes/salesOrder.routes";
import dashboardRoutes from "./routes/dashboard.routes";
import billingRoutes, { stripeWebhookHandler } from "./routes/billing.routes";
import { errorHandler } from "./middleware/errorHandler";

const app = express();

app.use(helmet());
app.use(cors({ origin: process.env.FRONTEND_URL || "*", credentials: true }));
app.use(morgan(process.env.NODE_ENV === "production" ? "combined" : "dev"));

// Límite de peticiones para mitigar fuerza bruta / abuso (ajustable por entorno)
app.use(rateLimit({ windowMs: 15 * 60 * 1000, max: 500 }));

// El webhook de Stripe necesita el body en crudo (raw), por eso se registra ANTES de express.json()
app.post("/api/billing/webhook", express.raw({ type: "application/json" }), stripeWebhookHandler);

app.use(express.json({ limit: "5mb" }));

app.get("/health", (_req, res) => res.json({ status: "ok", service: "inventpro-api" }));

app.use("/api/auth", authRoutes);
app.use("/api/products", productRoutes);
app.use("/api", catalogRoutes); // /warehouses, /categories, /suppliers, /customers
app.use("/api/stock", stockRoutes);
app.use("/api/purchase-orders", purchaseOrderRoutes);
app.use("/api/sales-orders", salesOrderRoutes);
app.use("/api/dashboard", dashboardRoutes);
app.use("/api/billing", billingRoutes);

app.use(errorHandler);

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`InventPro API escuchando en puerto ${PORT}`);
});
