import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

// Datos de ejemplo para probar el sistema rápidamente (empresa demo)
async function main() {
  const passwordHash = await bcrypt.hash("Demo1234!", 10);

  const company = await prisma.company.create({
    data: {
      name: "Ferretería El Tornillo Feliz",
      slug: "ferreteria-demo",
      subscriptionStatus: "TRIALING",
      trialEndsAt: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000),
      users: { create: { name: "Admin Demo", email: "admin@demo.com", passwordHash, role: "OWNER" } },
    },
  });

  const warehouse = await prisma.warehouse.create({
    data: { companyId: company.id, name: "Bodega Principal", isDefault: true },
  });

  const category = await prisma.category.create({ data: { companyId: company.id, name: "Herramientas" } });

  const product = await prisma.product.create({
    data: {
      companyId: company.id, categoryId: category.id, sku: "HER-001", name: "Martillo 16oz",
      unit: "UND", costPrice: 8.5, salePrice: 15.0, minStock: 5,
    },
  });

  await prisma.productStock.create({ data: { productId: product.id, warehouseId: warehouse.id, quantity: 20 } });

  console.log("Seed completado. Login demo -> email: admin@demo.com / password: Demo1234!");
}

main().finally(() => prisma.$disconnect());
