import React, { createContext, useContext, useEffect, useState } from "react";
import { api } from "../api/client";

interface Company {
  id: string; name: string; slug: string; subscriptionStatus: string; trialEndsAt?: string;
}
interface User { id: string; name: string; email: string; role: "OWNER" | "ADMIN" | "MANAGER" | "EMPLOYEE"; }

interface AuthContextValue {
  user: User | null;
  company: Company | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (companyName: string, ownerName: string, email: string, password: string) => Promise<void>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [company, setCompany] = useState<Company | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem("inventpro_token");
    if (!token) { setLoading(false); return; }
    api.get("/auth/me")
      .then((res) => { setUser(res.data.user); setCompany(res.data.company); })
      .catch(() => localStorage.removeItem("inventpro_token"))
      .finally(() => setLoading(false));
  }, []);

  async function login(email: string, password: string) {
    const res = await api.post("/auth/login", { email, password });
    localStorage.setItem("inventpro_token", res.data.token);
    setUser(res.data.user);
    setCompany(res.data.company);
  }

  async function register(companyName: string, ownerName: string, email: string, password: string) {
    const res = await api.post("/auth/register", { companyName, ownerName, email, password });
    localStorage.setItem("inventpro_token", res.data.token);
    setUser(res.data.user);
    setCompany(res.data.company);
  }

  function logout() {
    localStorage.removeItem("inventpro_token");
    setUser(null);
    setCompany(null);
  }

  return (
    <AuthContext.Provider value={{ user, company, loading, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth debe usarse dentro de AuthProvider");
  return ctx;
}
