import React from "react";
import { NavLink, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

const navItems = [
  { to: "/", label: "Panel General", icon: "📊" },
  { to: "/products", label: "Productos", icon: "📦" },
  { to: "/stock", label: "Movimientos de Stock", icon: "🔄" },
  { to: "/purchase-orders", label: "Órdenes de Compra", icon: "🧾" },
  { to: "/sales-orders", label: "Órdenes de Venta", icon: "🛒" },
  { to: "/suppliers", label: "Proveedores", icon: "🏭" },
  { to: "/customers", label: "Clientes", icon: "👥" },
  { to: "/billing", label: "Suscripción", icon: "💳" },
];

export default function Layout({ children }: { children: React.ReactNode }) {
  const { user, company, logout } = useAuth();
  const navigate = useNavigate();

  const trialBanner = company?.subscriptionStatus === "TRIALING" && company.trialEndsAt
    ? `Estás en periodo de prueba hasta ${new Date(company.trialEndsAt).toLocaleDateString()}.`
    : company?.subscriptionStatus === "PAST_DUE"
    ? "Tu pago está pendiente. Actualiza tu método de pago para evitar interrupciones."
    : null;

  return (
    <div className="flex min-h-screen">
      <aside className="w-64 bg-slate-900 text-slate-100 flex flex-col shrink-0">
        <div className="px-6 py-5 border-b border-slate-800">
          <h1 className="text-xl font-bold tracking-tight">Invent<span className="text-brand-400">Pro</span></h1>
          <p className="text-xs text-slate-400 mt-1 truncate">{company?.name}</p>
        </div>
        <nav className="flex-1 py-4 space-y-1 px-3">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.to === "/"}
              className={({ isActive }) =>
                `flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition ${
                  isActive ? "bg-brand-600 text-white" : "text-slate-300 hover:bg-slate-800"
                }`
              }
            >
              <span>{item.icon}</span>
              {item.label}
            </NavLink>
          ))}
        </nav>
        <div className="p-4 border-t border-slate-800">
          <p className="text-sm font-medium">{user?.name}</p>
          <p className="text-xs text-slate-400">{user?.role}</p>
          <button
            onClick={() => { logout(); navigate("/login"); }}
            className="mt-3 w-full text-sm bg-slate-800 hover:bg-slate-700 rounded-lg py-2 transition"
          >
            Cerrar sesión
          </button>
        </div>
      </aside>
      <main className="flex-1 flex flex-col">
        {trialBanner && (
          <div className="bg-amber-100 text-amber-800 text-sm px-6 py-2 border-b border-amber-200">{trialBanner}</div>
        )}
        <div className="p-8 flex-1">{children}</div>
      </main>
    </div>
  );
}
