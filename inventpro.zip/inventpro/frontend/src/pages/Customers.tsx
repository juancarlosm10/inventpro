import React, { useEffect, useState } from "react";
import { api } from "../api/client";
import Layout from "../components/Layout";

export default function Customers() {
  const [items, setItems] = useState<any[]>([]);
  const [form, setForm] = useState({ name: "", taxId: "", email: "", phone: "" });
  const [showForm, setShowForm] = useState(false);

  async function load() { setItems((await api.get("/customers")).data); }
  useEffect(() => { load(); }, []);

  async function handleCreate(e: React.FormEvent) {
    e.preventDefault();
    await api.post("/customers", form);
    setForm({ name: "", taxId: "", email: "", phone: "" });
    setShowForm(false);
    load();
  }

  return (
    <Layout>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Clientes</h1>
        <button onClick={() => setShowForm(!showForm)} className="bg-brand-600 hover:bg-brand-700 text-white text-sm font-medium px-4 py-2 rounded-lg">
          {showForm ? "Cancelar" : "+ Nuevo cliente"}
        </button>
      </div>
      {showForm && (
        <form onSubmit={handleCreate} className="bg-white border rounded-2xl p-5 mb-6 grid grid-cols-2 gap-3">
          <input required placeholder="Nombre" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="border rounded-lg px-3 py-2 text-sm" />
          <input placeholder="NIT / Identificación" value={form.taxId} onChange={(e) => setForm({ ...form, taxId: e.target.value })} className="border rounded-lg px-3 py-2 text-sm" />
          <input placeholder="Correo" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="border rounded-lg px-3 py-2 text-sm" />
          <input placeholder="Teléfono" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} className="border rounded-lg px-3 py-2 text-sm" />
          <button className="col-span-full bg-brand-600 hover:bg-brand-700 text-white rounded-lg py-2 text-sm font-medium">Guardar</button>
        </form>
      )}
      <div className="bg-white rounded-2xl shadow-sm border overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-slate-50 text-left text-slate-500"><tr><th className="px-4 py-3">Nombre</th><th className="px-4 py-3">NIT</th><th className="px-4 py-3">Correo</th><th className="px-4 py-3">Teléfono</th></tr></thead>
          <tbody className="divide-y">
            {items.map((c) => (
              <tr key={c.id}><td className="px-4 py-3">{c.name}</td><td className="px-4 py-3">{c.taxId}</td><td className="px-4 py-3">{c.email}</td><td className="px-4 py-3">{c.phone}</td></tr>
            ))}
          </tbody>
        </table>
        {items.length === 0 && <p className="text-center text-slate-400 py-8 text-sm">No hay clientes.</p>}
      </div>
    </Layout>
  );
}
