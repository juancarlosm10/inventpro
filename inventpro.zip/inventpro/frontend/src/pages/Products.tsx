import React, { useEffect, useState } from "react";
import { api } from "../api/client";
import Layout from "../components/Layout";

export default function Products() {
  const [items, setItems] = useState<any[]>([]);
  const [search, setSearch] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ sku: "", name: "", unit: "UND", costPrice: 0, salePrice: 0, minStock: 0 });
  const [error, setError] = useState("");

  async function load() {
    const res = await api.get("/products", { params: { search } });
    setItems(res.data.items);
  }

  useEffect(() => { load(); }, [search]);

  async function handleCreate(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    try {
      await api.post("/products", form);
      setShowForm(false);
      setForm({ sku: "", name: "", unit: "UND", costPrice: 0, salePrice: 0, minStock: 0 });
      load();
    } catch (err: any) {
      setError(err.response?.data?.error || "No se pudo crear el producto.");
    }
  }

  return (
    <Layout>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Productos</h1>
        <button onClick={() => setShowForm(!showForm)} className="bg-brand-600 hover:bg-brand-700 text-white text-sm font-medium px-4 py-2 rounded-lg">
          {showForm ? "Cancelar" : "+ Nuevo producto"}
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleCreate} className="bg-white border rounded-2xl p-5 mb-6 grid grid-cols-2 md:grid-cols-3 gap-4">
          <input required placeholder="SKU" value={form.sku} onChange={(e) => setForm({ ...form, sku: e.target.value })} className="border rounded-lg px-3 py-2 text-sm" />
          <input required placeholder="Nombre" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="border rounded-lg px-3 py-2 text-sm" />
          <input placeholder="Unidad (UND, KG...)" value={form.unit} onChange={(e) => setForm({ ...form, unit: e.target.value })} className="border rounded-lg px-3 py-2 text-sm" />
          <input required type="number" step="0.01" placeholder="Precio costo" value={form.costPrice} onChange={(e) => setForm({ ...form, costPrice: parseFloat(e.target.value) })} className="border rounded-lg px-3 py-2 text-sm" />
          <input required type="number" step="0.01" placeholder="Precio venta" value={form.salePrice} onChange={(e) => setForm({ ...form, salePrice: parseFloat(e.target.value) })} className="border rounded-lg px-3 py-2 text-sm" />
          <input type="number" placeholder="Stock mínimo" value={form.minStock} onChange={(e) => setForm({ ...form, minStock: parseInt(e.target.value || "0") })} className="border rounded-lg px-3 py-2 text-sm" />
          {error && <p className="col-span-full text-sm text-red-600">{error}</p>}
          <button className="col-span-full bg-brand-600 hover:bg-brand-700 text-white rounded-lg py-2 text-sm font-medium">Guardar</button>
        </form>
      )}

      <input
        placeholder="Buscar por nombre, SKU o código de barras..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        className="border rounded-lg px-3 py-2 text-sm mb-4 w-full max-w-md"
      />

      <div className="bg-white rounded-2xl shadow-sm border overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-slate-50 text-left text-slate-500">
            <tr>
              <th className="px-4 py-3">SKU</th>
              <th className="px-4 py-3">Nombre</th>
              <th className="px-4 py-3">Stock total</th>
              <th className="px-4 py-3">Costo</th>
              <th className="px-4 py-3">Venta</th>
              <th className="px-4 py-3">Estado</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {items.map((p) => (
              <tr key={p.id} className={p.isLowStock ? "bg-red-50" : ""}>
                <td className="px-4 py-3 font-mono text-xs">{p.sku}</td>
                <td className="px-4 py-3">{p.name}</td>
                <td className="px-4 py-3">{p.totalStock}</td>
                <td className="px-4 py-3">${Number(p.costPrice).toFixed(2)}</td>
                <td className="px-4 py-3">${Number(p.salePrice).toFixed(2)}</td>
                <td className="px-4 py-3">
                  {p.isLowStock ? <span className="text-red-600 font-medium">Stock bajo</span> : <span className="text-emerald-600">OK</span>}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {items.length === 0 && <p className="text-center text-slate-400 py-8 text-sm">No hay productos aún.</p>}
      </div>
    </Layout>
  );
}
