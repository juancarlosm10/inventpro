import React, { useEffect, useState } from "react";
import { api } from "../api/client";
import Layout from "../components/Layout";

interface Summary {
  totalProducts: number;
  totalInventoryValue: number;
  lowStockCount: number;
  lowStockItems: { id: string; name: string; sku: string; currentStock: number; minStock: number }[];
  openPurchaseOrders: number;
  openSalesOrders: number;
  recentMovements: any[];
}

function Card({ label, value, accent }: { label: string; value: string | number; accent: string }) {
  return (
    <div className="bg-white rounded-2xl shadow-sm border p-5">
      <p className="text-sm text-slate-500">{label}</p>
      <p className={`text-2xl font-bold mt-1 ${accent}`}>{value}</p>
    </div>
  );
}

export default function Dashboard() {
  const [data, setData] = useState<Summary | null>(null);

  useEffect(() => {
    api.get("/dashboard/summary").then((res) => setData(res.data));
  }, []);

  if (!data) return <Layout><p className="text-slate-500">Cargando panel...</p></Layout>;

  return (
    <Layout>
      <h1 className="text-2xl font-bold mb-6">Panel General</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <Card label="Productos activos" value={data.totalProducts} accent="text-slate-800" />
        <Card label="Valor de inventario" value={`$${data.totalInventoryValue.toLocaleString(undefined, { minimumFractionDigits: 2 })}`} accent="text-brand-600" />
        <Card label="Alertas de stock bajo" value={data.lowStockCount} accent="text-red-600" />
        <Card label="Órdenes abiertas (compra/venta)" value={`${data.openPurchaseOrders} / ${data.openSalesOrders}`} accent="text-slate-800" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-2xl shadow-sm border p-5">
          <h2 className="font-semibold mb-3">⚠️ Productos con stock bajo</h2>
          {data.lowStockItems.length === 0 ? (
            <p className="text-sm text-slate-500">Todo en orden, ningún producto está por debajo del mínimo.</p>
          ) : (
            <ul className="divide-y">
              {data.lowStockItems.map((item) => (
                <li key={item.id} className="py-2 flex justify-between text-sm">
                  <span>{item.name} <span className="text-slate-400">({item.sku})</span></span>
                  <span className="font-medium text-red-600">{item.currentStock} / mín. {item.minStock}</span>
                </li>
              ))}
            </ul>
          )}
        </div>

        <div className="bg-white rounded-2xl shadow-sm border p-5">
          <h2 className="font-semibold mb-3">🕒 Movimientos recientes</h2>
          <ul className="divide-y">
            {data.recentMovements.map((m) => (
              <li key={m.id} className="py-2 text-sm flex justify-between">
                <span>{m.product?.name} · {m.warehouse?.name}</span>
                <span className="text-slate-500">{m.type} · {m.quantity}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </Layout>
  );
}
