import React, { useEffect, useState } from "react";
import { api } from "../api/client";
import Layout from "../components/Layout";

export default function Stock() {
  const [movements, setMovements] = useState<any[]>([]);
  const [products, setProducts] = useState<any[]>([]);
  const [warehouses, setWarehouses] = useState<any[]>([]);
  const [form, setForm] = useState({ productId: "", warehouseId: "", type: "IN_ADJUSTMENT", quantity: 1, reason: "" });
  const [error, setError] = useState("");

  async function load() {
    const [m, p, w] = await Promise.all([
      api.get("/stock/movements"),
      api.get("/products", { params: { pageSize: 200 } }),
      api.get("/warehouses"),
    ]);
    setMovements(m.data.items);
    setProducts(p.data.items);
    setWarehouses(w.data);
  }

  useEffect(() => { load(); }, []);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    try {
      await api.post("/stock/movements", form);
      load();
    } catch (err: any) {
      setError(err.response?.data?.error || "No se pudo registrar el movimiento.");
    }
  }

  return (
    <Layout>
      <h1 className="text-2xl font-bold mb-6">Movimientos de Stock</h1>

      <form onSubmit={handleSubmit} className="bg-white border rounded-2xl p-5 mb-6 grid grid-cols-2 md:grid-cols-5 gap-3 items-end">
        <div>
          <label className="text-xs font-medium text-slate-500">Producto</label>
          <select required value={form.productId} onChange={(e) => setForm({ ...form, productId: e.target.value })} className="border rounded-lg px-3 py-2 text-sm w-full">
            <option value="">Selecciona...</option>
            {products.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
          </select>
        </div>
        <div>
          <label className="text-xs font-medium text-slate-500">Bodega</label>
          <select required value={form.warehouseId} onChange={(e) => setForm({ ...form, warehouseId: e.target.value })} className="border rounded-lg px-3 py-2 text-sm w-full">
            <option value="">Selecciona...</option>
            {warehouses.map((w) => <option key={w.id} value={w.id}>{w.name}</option>)}
          </select>
        </div>
        <div>
          <label className="text-xs font-medium text-slate-500">Tipo</label>
          <select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })} className="border rounded-lg px-3 py-2 text-sm w-full">
            <option value="IN_ADJUSTMENT">Entrada (ajuste)</option>
            <option value="OUT_ADJUSTMENT">Salida (ajuste)</option>
            <option value="IN_RETURN">Entrada (devolución cliente)</option>
            <option value="OUT_RETURN">Salida (devolución a proveedor)</option>
          </select>
        </div>
        <div>
          <label className="text-xs font-medium text-slate-500">Cantidad</label>
          <input required type="number" min={1} value={form.quantity} onChange={(e) => setForm({ ...form, quantity: parseInt(e.target.value) })} className="border rounded-lg px-3 py-2 text-sm w-full" />
        </div>
        <button className="bg-brand-600 hover:bg-brand-700 text-white rounded-lg py-2 text-sm font-medium">Registrar</button>
        {error && <p className="col-span-full text-sm text-red-600">{error}</p>}
      </form>

      <div className="bg-white rounded-2xl shadow-sm border overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-slate-50 text-left text-slate-500">
            <tr>
              <th className="px-4 py-3">Fecha</th>
              <th className="px-4 py-3">Producto</th>
              <th className="px-4 py-3">Bodega</th>
              <th className="px-4 py-3">Tipo</th>
              <th className="px-4 py-3">Cantidad</th>
              <th className="px-4 py-3">Usuario</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {movements.map((m) => (
              <tr key={m.id}>
                <td className="px-4 py-3">{new Date(m.createdAt).toLocaleString()}</td>
                <td className="px-4 py-3">{m.product?.name}</td>
                <td className="px-4 py-3">{m.warehouse?.name}</td>
                <td className="px-4 py-3">{m.type}</td>
                <td className="px-4 py-3">{m.quantity}</td>
                <td className="px-4 py-3">{m.user?.name}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {movements.length === 0 && <p className="text-center text-slate-400 py-8 text-sm">Aún no hay movimientos.</p>}
      </div>
    </Layout>
  );
}
