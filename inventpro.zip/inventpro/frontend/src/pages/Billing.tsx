import React, { useState } from "react";
import { api } from "../api/client";
import Layout from "../components/Layout";
import { useAuth } from "../context/AuthContext";

export default function Billing() {
  const { company } = useAuth();
  const [loading, setLoading] = useState(false);

  async function goCheckout() {
    setLoading(true);
    try {
      const res = await api.post("/billing/checkout");
      window.location.href = res.data.url;
    } finally {
      setLoading(false);
    }
  }

  async function goPortal() {
    setLoading(true);
    try {
      const res = await api.post("/billing/portal");
      window.location.href = res.data.url;
    } finally {
      setLoading(false);
    }
  }

  return (
    <Layout>
      <h1 className="text-2xl font-bold mb-6">Suscripción</h1>
      <div className="bg-white rounded-2xl shadow-sm border p-6 max-w-lg">
        <p className="text-sm text-slate-500 mb-1">Plan actual</p>
        <p className="text-lg font-semibold mb-4">Estándar — USD 30 / mes</p>
        <p className="text-sm mb-6">
          Estado: <span className="font-medium">{company?.subscriptionStatus}</span>
          {company?.subscriptionStatus === "TRIALING" && company.trialEndsAt && (
            <> · Prueba hasta {new Date(company.trialEndsAt).toLocaleDateString()}</>
          )}
        </p>
        {company?.subscriptionStatus === "ACTIVE" ? (
          <button onClick={goPortal} disabled={loading} className="bg-slate-800 hover:bg-slate-900 text-white rounded-lg px-4 py-2 text-sm font-medium">
            Gestionar suscripción
          </button>
        ) : (
          <button onClick={goCheckout} disabled={loading} className="bg-brand-600 hover:bg-brand-700 text-white rounded-lg px-4 py-2 text-sm font-medium">
            {loading ? "Redirigiendo..." : "Activar suscripción — $30/mes"}
          </button>
        )}
      </div>
    </Layout>
  );
}
