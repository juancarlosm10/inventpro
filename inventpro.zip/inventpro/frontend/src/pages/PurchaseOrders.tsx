import React, { useEffect, useState } from "react";
import { api } from "../api/client";
import Layout from "../components/Layout";

export default function PurchaseOrders() {
  const [orders, setOrders] = useState<any[]>([]);
  const [suppliers, setSuppliers] = useState<any[]>([]);
  const [warehouses, setWarehouses] = useState<any[]>([]);
  const [products, setProducts] = useState<any[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ supplierId: "", warehouseId: "", items: [{ productId: "", quantity: 1, unitCost: 0 }] });
  const [error, setError] = useState("");

  async function load() {
    const [o, s, w, p] = await Promise.all([
      api.get("/purchase-orders"), api.get("/suppliers"), api.get("/warehouses"), api.get("/products", { params: { pageSize: 200 } }),
    ]);
    setOrders(o.data); setSuppliers(s.data); setWarehouses(w.data); setProducts(p.data.items);
  }
  useEffect(() => { load(); }, []);

  function updateItem(idx: number, field: string, value: any) {
    const items = [...form.items];
    (items[idx] as any)[field] = value;
    setForm({ ...form, items });
  }

  async function handleCreate(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    try {
      await api.post("/purchase-orders", form);
      setShowForm(false);
      setForm({ supplierId: "", warehouseId: "", items: [{ productId: "", quantity: 1, unitCost: 0 }] });
      load();
    } catch (err: any) {
      setError(err.response?.data?.error || "No se pudo crear la orden.");
    }
  }

  async function receiveFull(order: any) {
    const items = order.items.filter((i: any) => i.receivedQty < i.quantity).map((i: any) => ({ itemId: i.id, receivedQty: i.quantity - i.receivedQty }));
    if (!items.length) return;
    await api.post(`/purchase-orders/${order.id}/receive`, { items });
    load();
  }

  return (
    <Layout>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Órdenes de Compra</h1>
        <button onClick={() => setShowForm(!showForm)} className="bg-brand-600 hover:bg-brand-700 text-white text-sm font-medium px-4 py-2 rounded-lg">
          {showForm ? "Cancelar" : "+ Nueva orden"}
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleCreate} className="bg-white border rounded-2xl p-5 mb-6 space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <select required value={form.supplierId} onChange={(e) => setForm({ ...form, supplierId: e.target.value })} className="border rounded-lg px-3 py-2 text-sm">
              <option value="">Proveedor...</option>
              {suppliers.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
            <select required value={form.warehouseId} onChange={(e) => setForm({ ...form, warehouseId: e.target.value })} className="border rounded-lg px-3 py-2 text-sm">
              <option value="">Bodega destino...</option>
              {warehouses.map((w) => <option key={w.id} value={w.id}>{w.name}</option>)}
            </select>
          </div>

          {form.items.map((item, idx) => (
            <div key={idx} className="grid grid-cols-3 gap-3">
              <select required value={item.productId} onChange={(e) => updateItem(idx, "productId", e.target.value)} className="border rounded-lg px-3 py-2 text-sm">
                <option value="">Producto...</option>
                {products.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
              </select>
              <input required type="number" min={1} placeholder="Cantidad" value={item.quantity} onChange={(e) => updateItem(idx, "quantity", parseInt(e.target.value))} className="border rounded-lg px-3 py-2 text-sm" />
              <input required type="number" step="0.01" placeholder="Costo unitario" value={item.unitCost} onChange={(e) => updateItem(idx, "unitCost", parseFloat(e.target.value))} className="border rounded-lg px-3 py-2 text-sm" />
            </div>
          ))}
          <button type="button" onClick={() => setForm({ ...form, items: [...form.items, { productId: "", quantity: 1, unitCost: 0 }] })} className="text-sm text-brand-600 font-medium">+ Agregar ítem</button>

          {error && <p className="text-sm text-red-600">{error}</p>}
          <button className="bg-brand-600 hover:bg-brand-700 text-white rounded-lg py-2 px-4 text-sm font-medium">Crear orden</button>
        </form>
      )}

      <div className="bg-white rounded-2xl shadow-sm border overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-slate-50 text-left text-slate-500">
            <tr><th className="px-4 py-3">Código</th><th className="px-4 py-3">Proveedor</th><th className="px-4 py-3">Total</th><th className="px-4 py-3">Estado</th><th className="px-4 py-3"></th></tr>
          </thead>
          <tbody className="divide-y">
            {orders.map((o) => (
              <tr key={o.id}>
                <td className="px-4 py-3 font-mono text-xs">{o.code}</td>
                <td className="px-4 py-3">{o.supplier?.name}</td>
                <td className="px-4 py-3">${Number(o.total).toFixed(2)}</td>
                <td className="px-4 py-3">{o.status}</td>
                <td className="px-4 py-3">
                  {(o.status === "ORDERED" || o.status === "PARTIALLY_RECEIVED") && (
                    <button onClick={() => receiveFull(o)} className="text-brand-600 font-medium text-xs">Recibir pendiente</button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {orders.length === 0 && <p className="text-center text-slate-400 py-8 text-sm">No hay órdenes de compra.</p>}
      </div>
    </Layout>
  );
}
